#ifndef GRANATA_H
#define GRANATA_H

#include "struttureDati.h"

void sparo(Mittente mittente, int fdScrittura, Posizione posPartenza, int direzione);

#endif