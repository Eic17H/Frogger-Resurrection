#ifndef COCCODRILLO_H
#define COCCODRILLO_H

#include <unistd.h>
#include "struttureDati.h"

void coccodrillo(int fdScrittura, Flusso flussoAttuale);

#endif