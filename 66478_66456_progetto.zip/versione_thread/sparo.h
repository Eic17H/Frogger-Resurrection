#ifndef GRANATA_H
#define GRANATA_H

#include "struttureDati.h"

void sparo(Mittente mittente, Posizione posPartenza, int direzione, TuttoBuffer* buffer);

#endif