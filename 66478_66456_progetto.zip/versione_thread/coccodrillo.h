#ifndef COCCODRILLO_H
#define COCCODRILLO_H

#include <unistd.h>
#include "struttureDati.h"
#include "thread.h"

void coccodrillo(Flusso flussoAttuale, TuttoBuffer* buffer);

#endif