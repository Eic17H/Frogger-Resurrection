#ifndef RANA_H
#define RANA_H

#include <unistd.h>
#include "struttureDati.h"
#include <sys/wait.h>
#include "thread.h"

void* rana(void* args);

#endif